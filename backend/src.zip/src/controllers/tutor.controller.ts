import { Request, Response } from "express";
import { TutorServices } from "../services/tutor.services";

export class TutorController {
  private services = new TutorServices();

  login = async (req: Request, res: Response) => {
    const { email, password } = req.body;
    const token = await this.services.login(email, password);
    if (!token) return res.status(401).json({ message: 'Credenciales inválidas' });
    res.status(200).json({ token });
  }

  changePassword = async (req: Request, res: Response) => {
    const { oldPassword, newPassword } = req.body;
    const id = req.auth?.id;
    const ok = await this.services.changePassword(id, oldPassword, newPassword);
    if (!ok) return res.status(400).json({ message: "Contraseña actual incorrecta" });
    res.status(200).json({ message: "Contraseña actualizada" });
  }

  createClase = async (req: Request, res: Response) => {
    const tutorId = req.auth?.id;
    const { cursoId, fecha, tema } = req.body;
    const clase = await this.services.createClase(tutorId, cursoId, fecha, tema);
    res.status(201).json(clase);
  }

  registrarAsistencia = async (req: Request, res: Response) => {
    const { claseId, asistencias } = req.body;
    await this.services.registrarAsistencia(claseId, asistencias);
    res.status(200).json({ message: "Asistencias registradas" });
  }

  registrarNota = async (req: Request, res: Response) => {
    const { claseId, notas } = req.body;
    await this.services.registrarNota(claseId, notas);
    res.status(200).json({ message: "Notas registradas" });
  }
}
