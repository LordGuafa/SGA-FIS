import { Request, Response } from "express";
import { ParticipanteServices } from "../services/participante.services";

export class ParticipanteController {
  private services = new ParticipanteServices();

  login = async (req: Request, res: Response) => {
    const { email, password } = req.body;
    const token = await this.services.login(email, password);
    if (!token) return res.status(401).json({ message: 'Credenciales inválidas' });
    res.status(200).json({ token });
  }

  changePassword = async (req: Request, res: Response) => {
    const { oldPassword, newPassword } = req.body;
    const id = req.auth?.id;
    const ok = await this.services.changePassword(id, oldPassword, newPassword);
    if (!ok) return res.status(400).json({ message: "Contraseña actual incorrecta" });
    res.status(200).json({ message: "Contraseña actualizada" });
  }

  getAsistencias = async (req: Request, res: Response) => {
    const participanteId = req.auth?.id;
    const asistencias = await this.services.getAsistencias(participanteId);
    res.status(200).json(asistencias);
  }

  getNotas = async (req: Request, res: Response) => {
    const participanteId = req.auth?.id;
    const notas = await this.services.getNotas(participanteId);
    res.status(200).json(notas);
  }
}
