export interface IInscription {
  id?: number;
  curso_id: number;
  participante_id: number;
  modalidad_id: number;
  fecha_inscripcion?: Date;

}
