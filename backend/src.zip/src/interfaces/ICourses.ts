export interface ICourse {
  id?: number;
  name: string;
  description: string;
}