export interface IAttendance {
  id?: number;
  clase_id: number;
  participante_id: number;
  presente: boolean;
}