export interface INote {
  id?:number
  clase_id: number;
  participante_id: number;
  nota: number;
  observaciones?: string;
}