export interface IAssign { 
    id?: number;
    tutor_id: number;
    curso_id: number;
    fecha_asignacion?: Date;

}