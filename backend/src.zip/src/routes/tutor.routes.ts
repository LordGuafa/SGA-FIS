import { Router } from "express";
import { authMiddleware } from "../middlewares/auth.middleware";
import { checkRole } from "../middlewares/roleCheck.middleware.";
import { TutorController } from "../controllers/tutor.controller";

const tutorRouter = Router();
const tutorController = new TutorController();

tutorRouter.post("/login", tutorController.login);

tutorRouter.use(authMiddleware, checkRole(2));

tutorRouter.post("/change-password", tutorController.changePassword);
tutorRouter.post("/clases", tutorController.createClase);
tutorRouter.post("/asistencias", tutorController.registrarAsistencia);
tutorRouter.post("/notas", tutorController.registrarNota);

export default tutorRouter;
