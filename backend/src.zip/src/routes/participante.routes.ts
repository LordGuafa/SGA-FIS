import { Router } from "express";
import { authMiddleware } from "../middlewares/auth.middleware";
import { checkRole } from "../middlewares/roleCheck.middleware.";
import { ParticipanteController } from "../controllers/participante.controller";

const participanteRouter = Router();
const participanteController = new ParticipanteController();

participanteRouter.post("/login", participanteController.login);

participanteRouter.use(authMiddleware, checkRole(3));

participanteRouter.post("/change-password", participanteController.changePassword);
participanteRouter.get("/asistencias", participanteController.getAsistencias);
participanteRouter.get("/notas", participanteController.getNotas);

export default participanteRouter;
